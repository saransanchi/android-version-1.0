package com.flover.seng.util

interface ClickInitializer{
    fun initialize(anyButtonId : Int)
}